<?php

$SQL[] = "ALTER TABLE downloads_filebackup ADD b_filereal VARCHAR( 255 ) NOT NULL DEFAULT '0';";
