<?php

$SQL[] = "ALTER TABLE downloads_temp_records ADD record_default TINYINT( 1 ) NOT NULL DEFAULT '0';";