<?php

$SQL[] = "UPDATE downloads_mime set mime_img=replace(mime_img,'folder_mime_types','mime_types');";



