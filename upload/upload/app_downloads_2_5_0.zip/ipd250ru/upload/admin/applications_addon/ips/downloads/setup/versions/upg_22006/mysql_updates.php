<?php

$SQL[] = "ALTER TABLE downloads_files ADD file_nexus TEXT NOT NULL DEFAULT '';";