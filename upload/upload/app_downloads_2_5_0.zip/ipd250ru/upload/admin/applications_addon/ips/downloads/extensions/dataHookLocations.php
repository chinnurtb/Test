<?php
/**
 * <pre>
 * Invision Power Services
 * IP.Board v2.5.0
 * Define data hook locations (Downloads)
 * Last Updated: $Date: 2011-02-01 09:40:30 -0500 (Tue, 01 Feb 2011) $
 * </pre>
 *
 * @author 		$Author: ips_terabyte $
 * @copyright	(c) 2001 - 2009 Invision Power Services, Inc.
 * @license		http://www.invisionpower.com/community/board/license.html
 * @package		IP.Board
 * @subpackage	Core
 * @link		http://www.invisionpower.com
 * @version		$Rev: 7686 $
 */

$dataHookLocations = array(

	/* POSTING DATA LOCATIONS */
	array( 'downloadAddFile', 'Add Download' ),
	array( 'downloadEditFile', 'Edit Download' ),
	array( 'downloadUpdateCategoryInfo', 'Update Downloads Category Info' ),
	array( 'downloadRebuildStatsCache', 'Rebuild Downloads Statistics Cache' ),
	array( 'downloadAddFileComment', 'Add File Comment' ),
	array( 'downloadEditFileComment', 'Edit File Comment' ),
	array( 'downloadCommentAddPostSave', 'Add File Comment (post save)' ),
	array( 'downloadCommentEditPostSave', 'Edit File Comment (post save)' ),
	array( 'downloadCommentPostDelete', 'Delete File Comment (post delete)' ),
	array( 'downloadCommentToggleVisibility', 'Toggle File Comment Visibility (post delete)' ),
);