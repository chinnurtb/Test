/************************************************/
/* IPB3 Javascript								*/
/* -------------------------------------------- */
/* acp.homepage.js - Homepage javascript 		*/
/* (c) IPS, Inc 2008							*/
/* -------------------------------------------- */
/* Author: Brandon Farber						*/
/************************************************/

ACPDownloads = {
	
	/*------------------------------*/
	/* Constructor 					*/
	init: function()
	{
		Debug.write("Initializing acp.downloads.js");

		document.observe("dom:loaded", function(){
			if( $('mem_name') )
			{
				this.autoComplete = new ipb.Autocomplete( $('mem_name'), { multibox: false, url: acp.autocompleteUrl, templates: { wrap: acp.autocompleteWrap, item: acp.autocompleteItem } } );
			}
			else if( $('modmid') )
			{
				this.autoComplete = new ipb.Autocomplete( $('modmid'), { multibox: false, url: acp.autocompleteUrl, templates: { wrap: acp.autocompleteWrap, item: acp.autocompleteItem } } );
			}
			else if( $('member') )
			{
				this.autoComplete = new ipb.Autocomplete( $('member'), { multibox: false, url: acp.autocompleteUrl, templates: { wrap: acp.autocompleteWrap, item: acp.autocompleteItem } } );
			}
		});
	},
	
	confirmDelete: function( catid )
	{
		if( catid < 1 )
		{
			alert( "Не найдена категория с таким id" );
		}
		else
		{
			acp.confirmDelete( ipb.vars['app_url'].replace(/&amp;/g, '&' ) + 'module=categories&section=categories&code=dodelete&c=' + catid, "Вы действительно хотите удалить категорию и все ее содержимое? Внимание, это действие нельзя будет отменить!" );
		}
	},
	
	confirmEmpty: function( catid )
	{
		if( catid < 1 )
		{
			alert( "Не найдена категория с таким id" );
		}
		else
		{
			acp.confirmDelete( ipb.vars['app_url'].replace(/&amp;/g, '&' ) + 'module=categories&section=categories&code=doempty&c=' + catid, "Вы действительно хотите очистить категорию? Внимание, это действие нельзя будет отменить!" );
		}
	}

};

ACPDownloads.init();