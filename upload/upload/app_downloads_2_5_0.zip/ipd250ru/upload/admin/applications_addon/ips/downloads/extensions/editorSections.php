<?php

/**
 * <pre>
 * Invision Power Services
 * IP.Board v2.5.0
 * BBCode - determines which sections bbcode can be used in
 * Last Updated: $Date: 2011-04-20 18:01:37 -0400 (Wed, 20 Apr 2011) $
 * </pre>
 *
 * @author 		$Author: bfarber $
 * @copyright	(c) 2001 - 2009 Invision Power Services, Inc.
 * @license		http://www.invisionpower.com/community/board/license.html
 * @package		IP.Downloads
 * @link		http://www.invisionpower.com
 * @since		6/24/2008
 * @version		$Revision: 8419 $
 */

if ( ! defined( 'IN_IPB' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded all the relevant files.";
	exit();
}

/*
 * An array of key => value pairs
 * When going to parse, the key should be passed to the editor
 *  to determine which bbcodes should be parsed in the section
 *
 */
$BBCODE	= array(
				'idm_submit'		=> ipsRegistry::getClass('class_localization')->words['ctype__idmfile'],
				);